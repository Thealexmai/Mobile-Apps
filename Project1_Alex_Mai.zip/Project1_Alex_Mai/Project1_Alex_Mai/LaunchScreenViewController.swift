//
//  LaunchScreenViewController.swift
//  Project1_Alex_Mai
//
//  Created by Alex Mai on 11/5/16.
//  Copyright © 2016 Mobile Application Development. All rights reserved.
//

import UIKit

class LaunchScreenViewController: UIViewController {
    
}
